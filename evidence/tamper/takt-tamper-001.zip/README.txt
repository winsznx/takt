Takt claim packet — TAKT-DEMO-001

What this is
A set of documents prepared by the worker with Takt, a tool that compares work records.
It is not legal advice and it has not been sent to the Labor Commissioner or anyone else.

What Takt concluded
Confirmed work in the claimed pay periods earned $1,489.25; the wage statements paid $1,480.00. Difference: $9.25.

What Takt did not conclude
Takt does not decide whether an employer broke the law, why records differ, or whether a claim will succeed.

Files
claim-form-1.pdf       DLSE Form 1 (REV. 07/2025), filled from your confirmed facts. Review it, then sign and date it yourself.
dlse-form-55.xls       DLSE Form 55 worksheet, per pay period.
evidence-index.pdf     Every record, fact, discrepancy, and calculation with its source location.
calculation.csv        Each calculation line: minutes x rate x multiplier / 60.
manifest.json          Machine-readable record of inputs, hashes, rules, and results.
sources/               Copies of original files, only if you chose to include them.

Check this packet
Anyone can re-verify it with the Takt verifier (npm run verify:packet -- <packet.zip>) or on the Takt Verify page.

Official instructions: https://www.dir.ca.gov/dlse/HowToFileWageClaim.htm
